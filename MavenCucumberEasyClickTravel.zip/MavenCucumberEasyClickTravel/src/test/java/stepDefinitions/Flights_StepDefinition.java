package stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.AbstractPage;
import pageObjects.CarsPage;
import pageObjects.FlightsPage;
import pageObjects.FlightsSearchResultsPage;
import pageObjects.HomePage;
import pageObjects.HotelsPage;
import pageObjects.LandingonPage;

public class Flights_StepDefinition {
	
	WebDriver driver = new FirefoxDriver();
	LandingonPage landingonPage;
	HomePage homePage;
	FlightsPage flightsPage;
	FlightsSearchResultsPage flightsSearchResultsPage;
	
	@Given("^I am also on the EasyClickTravel site$")
	public void i_am_also_on_the_EasyClickTravel_site() throws Throwable {
	    landingonPage = new LandingonPage(driver);
	    landingonPage.navigateToWebApp();
	}
	
	@When("^I click flights tab$")
	public void i_click_flights_tab() throws Throwable {
		landingonPage.navigateToFlightsPage();
	}

	@Then("^I verify this flights page URL contains \"(.*?)\"$")
	public void i_verify_this_flights_page_URL_contains(String url) throws Throwable {
		Assert.assertTrue(driver.getCurrentUrl().contains(url));
	}
	
	@And("^I close the browser for flights page$") 
	public void i_close_the_browser_for_flights_page() throws Throwable {
	    landingonPage.closeDriver();
	}
	
	@When("^I click the One Way tab$")
    public void i_click_the_One_Way_tab() throws Throwable {
        FlightsPage flights = new FlightsPage(driver);
	    flights.onewayClicked();
    }
	
	@When("^I click the calendar control and pass date '(\\d+)/(\\d+)/(\\d+)'$")
	public void i_click_the_calendar_control_and_pass_date(int mm, int dd, int yyyy) throws Throwable {
		String month_day_year = String.valueOf(mm) + "/" + String.valueOf(dd) +"/" + String.valueOf(yyyy);
	    System.out.println("Date is " + month_day_year);
	    Date d = new Date(month_day_year);
		SimpleDateFormat dt = new SimpleDateFormat("MMMMM/dd/yyyy");
		String checkIndate = dt.format(d);
		System.out.println("checkIndate is " + checkIndate);
		String[] split = checkIndate.split("/");
		System.out.println(split[0] + " " + split[1] + " " + split[2]);
		String checkInmonth_year = split[0]+ ", " + split[2];
		String checkInday = split[1];
	    
	    System.out.println("month_year is "+ checkInmonth_year);
	    System.out.println("day is "+ checkInday);
	    FlightsPage flights = new FlightsPage(driver);
	    flights.departCalendarClicked(checkInmonth_year, checkInday);
	}
	
	@When("^I populate the one-way flights form$")
	public void i_populate_the_one_way_flights_form(DataTable table) throws Throwable {
		FlightsPage flights = new FlightsPage(driver);   
		 flights.populateOneWayFlightsForm(table);
	}
	
	@When("^I click link Flexible Options$")
	public void i_click_link_Flexible_Options() throws Throwable {
		FlightsPage flights = new FlightsPage(driver);
	    flights.flexibleOptionsClicked();
	}
	
	@When("^I click Non-stop flights preference$")
	public void i_click_Non_stop_flights_preference() throws Throwable {
		FlightsPage flights = new FlightsPage(driver);
	    flights.nonStopClicked();
	}
	
	@When("^Seach for flight button is clicked with this flight form criteria$")
	public void seach_for_flight_button_is_clicked_with_this_flight_form_criteria() throws Throwable {
		FlightsPage flights = new FlightsPage(driver);
		flights.searchForFlightsClicked();
	}
	
	@Then("^you will get flight search results on titles$")
	public void you_will_get_flight_search_results_on_titles() throws Throwable {
		flightsSearchResultsPage = new FlightsSearchResultsPage(driver);
		Assert.assertTrue(flightsSearchResultsPage.flightsSearchTitleText().contains("One Way"));
	}

	@Then("^you will get flight search results on selected date$")
	public void you_will_get_flight_search_results_on_selected_date() throws Throwable {
		flightsSearchResultsPage = new FlightsSearchResultsPage(driver);
		Assert.assertTrue(flightsSearchResultsPage.flightsSearchSelectedDateText().contains("Selected Dates: Fri, Apr 28"));
	}
	
	@Then("^close flights-open browser$")
	public void close_flights_open_browser() throws Throwable {
		flightsSearchResultsPage.closeDriver();
	}



}
