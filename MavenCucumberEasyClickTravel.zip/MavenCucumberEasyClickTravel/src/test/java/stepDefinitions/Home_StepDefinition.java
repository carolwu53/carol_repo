package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.CarsPage;
import pageObjects.FlightsPage;
import pageObjects.HomePage;
import pageObjects.HotelsPage;
import pageObjects.LandingonPage;

public class Home_StepDefinition  {
	
	WebDriver driver = new FirefoxDriver();
	LandingonPage landingonPage;
	HomePage homePage;
	HotelsPage hotelsPage;
	FlightsPage flightsPage;
	CarsPage carsPage;
	
	@Given("^I am on the EasyClickTravel site$")
	public void i_am_on_the_EasyClickTravel_site() throws Throwable {
	    landingonPage = new LandingonPage(driver);
	    landingonPage.navigateToWebApp();
	}

	@When("^I click Home tab$")
	public void i_click_Home_tab() throws Throwable {
		homePage = landingonPage.navigateToHomePage();
	}

	@Then("^I verify this page URL contains \"(.*?)\"$")
	public void i_verify_this_page_URL_contains(String url1) throws Throwable {
		Assert.assertTrue(driver.getCurrentUrl().contains(url1));
	}

	@And("^I close the browser$")
	public void i_close_the_browser() throws Throwable {
	    landingonPage.closeDriver();
	}
	
	@When("^I click Hotels radio button$")
	public void i_click_Hotels_radio_button() throws Throwable {
	   homePage = new HomePage(driver);
	   homePage.hotelsClicked();
	}

	@When("^I populate the form$")
	public void i_populate_the_form(DataTable table) throws Throwable {
		homePage = new HomePage(driver);
	    homePage.populateHotelsForm(table);
	}

//	@When("^SearchByPrice radio button is checked$")
//	public void searchbyprice_radio_button_is_checked() throws Throwable {
//	   homePage.
//	}

	@When("^Seach Now button is clicked with this form criteria$")
	public void seach_Now_is_clicked_with_this_form_criteria() throws Throwable {
	    homePage.btnSearchNowClicked();
	}

	@Then("^you will get Hotels Search Results$")
	public void you_will_get_Hotel_Search_Results() throws Throwable {
	    hotelsPage = new HotelsPage(driver);
	    String hotelsSearchTitle = hotelsPage.verifyHotelsResultTitle();
	    Assert.assertTrue(hotelsSearchTitle.contains("Hotels Search Results"));
	    
	}

	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
	    homePage.closeDriver();
	    //flightsPage.closeDriver();
	}
	
	@When("^I click Flights radio button$")
	public void i_click_Flights_radio_button() throws Throwable {
		homePage = new HomePage(driver);
		homePage.flightsClicked();
	}
	
	@When("^I populate the flights form$")
	public void i_populate_the_flights_form(DataTable table) throws Throwable {
		homePage.populateFlightsForm(table);
	}

	@When("^Seach for fright button is clicked with this form criteria$")
	public void seach_for_fright_button_is_clicked_with_this_form_criteria() throws Throwable {
		homePage.btnSearchForFlightClicked();
	}

	@Then("^you will get Flight Search Results$")
	public void you_will_get_Flight_Search_Results() throws Throwable {
		flightsPage = new FlightsPage(driver);
	    String flightsSearchTitle = flightsPage.verifyFlightsResultTitle();
	    Assert.assertTrue(flightsSearchTitle.contains("Flight Search Results"));
	}
	
   //Renting Cars function
	@When("^I click Cars radio button$")
	public void i_click_Cars_radio_button() throws Throwable {
		homePage = new HomePage(driver);
		homePage.carsClicked();
	}

	@When("^I populate Cars form$")
	public void i_populate_Cars_form(DataTable table) throws Throwable {
		homePage.populateCarsForm(table);
	}

	@When("^Seach Now button is clicked with Cars form criteria$")
	public void seach_Now_button_is_clicked_with_Cars_form_criteria() throws Throwable {
		homePage.btnSearchForCarsClicked();
	}

	@Then("^you will get Cars Search Results$")
	public void you_will_get_Cars_Search_Results() throws Throwable {
		carsPage = new CarsPage(driver);
	    String carsSearchTitle = carsPage.verifyCarsResultTitle();
	    Assert.assertTrue(carsSearchTitle.contains("Car Search"));
	}

}
