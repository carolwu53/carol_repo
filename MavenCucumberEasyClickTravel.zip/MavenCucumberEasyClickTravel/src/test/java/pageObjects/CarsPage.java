package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class CarsPage extends AbstractPage {

	public CarsPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String verifyCarsResultTitle() {
		String CarsSearchResultTitle = driver.getTitle();
		System.out.println("Cars Search Results Title is: " + CarsSearchResultTitle);
		return CarsSearchResultTitle;
	}
}
