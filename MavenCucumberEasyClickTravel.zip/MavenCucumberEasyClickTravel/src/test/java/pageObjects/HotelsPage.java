package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelsPage extends AbstractPage{
	
	@FindBy(id="imgHtlView") WebElement imgHotelsSearchResults;
	
	public HotelsPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String verifyHotelsResultTitle() {
		String hotelsSearchResultTitle = driver.getTitle();
		System.out.println("Hotels Search Results are: " + hotelsSearchResultTitle);
		return hotelsSearchResultTitle;
	}

}
