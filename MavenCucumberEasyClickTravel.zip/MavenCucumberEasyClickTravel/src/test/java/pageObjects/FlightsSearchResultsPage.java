package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FlightsSearchResultsPage extends AbstractPage{
	
	@FindBy(how = How.XPATH, using="//td[contains(text( ), 'One Way')]")
	WebElement confirmTitleText;
	@FindBy(id="selectedDates") WebElement confirmSelectedDates;

	public FlightsSearchResultsPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String flightsSearchTitleText(){
		waitForPageUntilElementIsVisible(By.xpath("//td[contains(text( ), 'One Way')]"), 8000);
		System.out.println("Confirmed the title is:" + confirmTitleText.getText());
		return confirmTitleText.getText();
	}
	
	public String flightsSearchSelectedDateText(){
		return confirmSelectedDates.getText();
	}
	
	

}
