package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.DataTable;


public class FlightsPage extends AbstractPage{
	
	public FlightsPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String verifyFlightsResultTitle() {
		String flightsSearchResultTitle = driver.getTitle();
		System.out.println("Hotels Search Results are: " + flightsSearchResultTitle);
		return flightsSearchResultTitle;
	}
	
	
	/************One Way flights search section**************/
	@FindBy(id="TGS_f_aOneWay") WebElement tabOneWay;
	@FindBy(id="TGS_f_txtFrom") WebElement txtFrom;
	@FindBy(id="TGS_f_txtTo") WebElement txtTo;
	@FindBy(id="TGS_f_departDate") WebElement txtDepartDate;
	@FindBy(id="TGS_f_departTime") WebElement ddlDepartTime;
	@FindBy(id="TGS_f_cmbAdults") WebElement ddlAdults;
	@FindBy(id="TGS_f_cmbChildren") WebElement ddlChildren;
	@FindBy(id="tgs_f_cmbAge1") WebElement ddlChild1;
	@FindBy(id="tgs_f_cmbAge2") WebElement ddlChild2;
	@FindBy(id="TGS_f_cmbSeniors") WebElement ddlSeniors;
	@FindBy(id="TGS_f_cmbInfants") WebElement ddlInfants;
	@FindBy(id="TGS_f_cmbAirlines") WebElement ddlAirlines;
	@FindBy(id="TGS_f_cmbFlightClass") WebElement ddlFlightClass;
	@FindBy(id="TGS_f_butSearch") WebElement btnSearchForFlight;
	@FindBy(xpath="//a[contains(text( ), 'Flexible options')]") WebElement lnkFlexibleOptions;
	@FindBy(id="TGS_f_cbNonStop") WebElement lnkNonStop;
	@FindBy(id="TGS_f_DEcalendar") WebElement btnDepartCalendar;
	@FindBy(id="TGS_f_REcalendar") WebElement btnReturnCalendar;
	@FindBy(xpath="//div[@class='calendar']/table/tbody/tr/td/table/thead/tr/td[@class='title']") List<WebElement> colMonth_Year;
	@FindBy(xpath="//div[@class='calendar']/table/tbody/tr/td[1]/table/tbody/tr/td[@class='day false' or @class='day false weekend']") List<WebElement> colDays;
	@FindBy(id="TGS_f_butSearch") WebElement btnSearchForFlights;
	
	
	public FlightsPage onewayClicked(){
		waitForPageUntilElementIsVisible(By.id("TGS_f_aOneWay"), 8000);
		System.out.println("One Way tab tag is = " + tabOneWay.getTagName());
		tabOneWay.click();
		return new FlightsPage(driver);
	}
	
	public void departCalendarClicked(String month_year, String days) throws InterruptedException{
		String month = month_year.split(", ")[0];
		String year = month_year.split(", ")[1];
		String month_day_year = month + "/" + days + "/" + year;
		System.out.println("month_day_year = " + month_day_year);
		boolean flag = true;
		if(flag){
			System.out.println("btnDepartCalendar tag is: " + btnDepartCalendar.getTagName());
			btnDepartCalendar.click();
			flag = false;
			selectDate(month_year, days);
		}
		else{
			btnDepartCalendar.sendKeys(month_day_year);
		}
	}
	
	public void returnCalendarClicked(String month_year, String days) throws InterruptedException{
		String month = month_year.split(", ")[0];
		String year = month_year.split(", ")[1];
		String month_day_year = month + "/" + days + "/" + year;
		
		if(btnReturnCalendar.isSelected()){
			selectDate(month_year, days);
		}
		else{
			btnReturnCalendar.clear();
			btnReturnCalendar.sendKeys(month_day_year);
		}
	}
	
	
	public void selectDate(String month_year, String day) throws InterruptedException
	{
		for(int i=0; i<colMonth_Year.size(); i++)
		{
			System.out.println("****");
			System.out.println(colMonth_Year.get(i).getText());
			//selecting the month
			if(colMonth_Year.get(i).getText().equals(month_year))
			{
				//selecting the date
				System.out.println("-------------------");
				//List<WebElement> days = driver.findElements(By.xpath("//div[@class='calendar']/table/tbody/tr/td[1]/table/tbody/tr/td[@class='day false' or @class='day false weekend']"));
				for(WebElement d:colDays){
					System.out.println(d.getText());
					if(d.getText().equals(day)){
						d.click();
						return;
					  }
			      }
		    }
		Thread.sleep(3000);
	   }
   }
	
	public FlightsPage populateOneWayFlightsForm(DataTable onewaytable) throws InterruptedException{
		List<List<String>> data = onewaytable.raw();
	    System.out.println(data.get(1).get(1));
	   
	    txtFrom.sendKeys(data.get(1).get(1));
	    Thread.sleep(1000);
	    txtTo.sendKeys(data.get(2).get(1));
//	    txtDepartDate.clear();
//	    txtDepartDate.sendKeys(data.get(3).get(1));
	    new Select(ddlDepartTime).selectByVisibleText(data.get(3).get(1));
	    new Select(ddlAdults).selectByVisibleText(data.get(4).get(1));
	    if(data.get(5).get(1).equals("2"))
	    {
	        new Select(ddlChildren).selectByVisibleText(data.get(5).get(1));
	        new Select(ddlChild1).selectByVisibleText(data.get(8).get(1));
	        new Select(ddlChild2).selectByVisibleText(data.get(9).get(1));
	    }
	    new Select(ddlSeniors).selectByVisibleText(data.get(6).get(1));
	    new Select(ddlInfants).selectByVisibleText(data.get(7).get(1));
	    new Select(ddlAirlines).selectByVisibleText(data.get(10).get(1));
	    new Select(ddlFlightClass).selectByVisibleText(data.get(11).get(1));
	    return new FlightsPage(driver);
	  }
		
	 public FlightsPage flexibleOptionsClicked(){
		waitForPageUntilElementIsVisible(By.xpath("//a[contains(text( ), 'Flexible options')]"), 8000);
		System.out.println("Flexible Options tag is = " + lnkFlexibleOptions.getTagName());
		lnkFlexibleOptions.click();
		return new FlightsPage(driver);
	}
	 
	 public FlightsPage nonStopClicked(){
			waitForPageUntilElementIsVisible(By.id("TGS_f_cbNonStop"), 5000);
			System.out.println("Non-stop flights  tag is = " + lnkNonStop.getTagName());
			lnkNonStop.click();
			return new FlightsPage(driver);
		}
	 
	 public FlightsSearchResultsPage searchForFlightsClicked(){
		 btnSearchForFlights.click();
		 return new FlightsSearchResultsPage(driver);
	 }
	
		
	
	

}
