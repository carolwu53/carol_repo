package pageObjects;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;

public class HomePage extends AbstractPage {
	
/************Hotels search section**************/	
    @FindBy(id="TGS_sb_hImg") WebElement rbtHotels;
	@FindBy(id="TGS_h_txtDestination") WebElement inputDestination;
	@FindBy(id="TGS_h_checkInDate") WebElement inputCheckIn;
	@FindBy(id="TGS_h_checkOutDate") WebElement inputCheckOut;
	@FindBy(id="TGS_h_numOfRooms") WebElement ddlRooms;
	@FindBy(id="TGS_h_numOfAdults1") WebElement ddlAdults_rm1;
	@FindBy(id="TGS_h_numOfChildren1") WebElement ddlChildren_rm1;
	@FindBy(id="TGS_h_numOfAdults2") WebElement ddlAdults_rm2;
	@FindBy(id="TGS_h_numOfChildren2") WebElement ddlChildren_rm2;
	@FindBy(id="TGS_h_room1_child1_AgeCombo") WebElement ddlChild1_rm1;
	@FindBy(id="TGS_h_room1_child2_AgeCombo") WebElement ddlChild2_rm1;
	@FindBy(id="TGS_h_room2_child1_AgeCombo") WebElement ddlChild1_rm2;
	@FindBy(id="TGS_h_rbSearchByPrice") WebElement rbSearchByPrice;
	@FindBy(id="TGS_h_butSearch") WebElement btnSearchNow;
	
	public HomePage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
		//System.out.println(driver.getCurrentUrl());
	}
	
	
	
	public HomePage hotelsClicked(){
		waitForPageUntilElementIsVisible(By.id("TGS_sb_hImg"), 15000);
		rbtHotels.click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return new HomePage(driver);
	}
	
	public HomePage populateHotelsForm(DataTable table) throws InterruptedException{
		//System.out.println(table);
	    List<List<String>> data = table.raw();
	    System.out.println(data.get(1).get(1));
	   
	    inputDestination.sendKeys(data.get(1).get(1));
	    inputCheckIn.clear();
	    inputCheckIn.sendKeys(data.get(2).get(1));
	    inputCheckOut.clear();
	    inputCheckOut.sendKeys(data.get(3).get(1));
	    if(data.get(4).get(1).equals("1"))
	    {
	        new Select(ddlRooms).selectByVisibleText(data.get(4).get(1));
	        new Select(ddlAdults_rm1).selectByVisibleText(data.get(5).get(1));
	        new Select(ddlChildren_rm1).selectByVisibleText(data.get(7).get(1));
	        if(data.get(7).get(1).equals("2")){
	        	new Select(ddlChild1_rm1).selectByVisibleText(data.get(9).get(1));
		        new Select(ddlChild2_rm1).selectByVisibleText(data.get(10).get(1));
	        }
	    }
	    else{
	    	new Select(ddlRooms).selectByVisibleText(data.get(4).get(1));
	        new Select(ddlAdults_rm1).selectByVisibleText((data.get(5).get(1)));
	        new Select(ddlChildren_rm1).selectByVisibleText(data.get(7).get(1));
	        System.out.println("number of Children in room1 = " + data.get(7).get(1));
	        //waitForPageUntilElementIsVisible(By.id("TGS_h_room1_child1_AgeCombo"), 8000);
	        Thread.sleep(5000);
	        if(data.get(7).get(1).equals("2")){
	        	System.out.println("condition of children in room1 = " + data.get(7).get(1).equals(2));
	        	new Select(ddlChild1_rm1).selectByVisibleText(data.get(9).get(1));
		        new Select(ddlChild2_rm1).selectByVisibleText(data.get(10).get(1));
	           }
	        new Select(ddlAdults_rm2).selectByVisibleText((data.get(6).get(1)));
	        new Select(ddlChildren_rm2).selectByVisibleText(data.get(8).get(1));
	        System.out.println("number of Children in room2 = " + data.get(8).get(1));
	        waitForPageUntilElementIsVisible(By.id("TGS_h_room2_child1_AgeCombo"), 5000);
	        if(data.get(8).get(1).equals("1")){
	        	new Select(ddlChild1_rm2).selectByVisibleText(data.get(11).get(1));
	        	System.out.println("Age of Child1 in room2 = " + data.get(11).get(1));
		        }
	       }
	    return new HomePage(driver);
	  }
	
	public HotelsPage btnSearchNowClicked(){
		btnSearchNow.click();
		return new HotelsPage(driver);
	}
	
	
	/************Flights search section**************/
	@FindBy(id="TGS_sb_fImg") WebElement rbtFlights;
	@FindBy(id="TGS_f_txtFrom") WebElement txtFrom;
	@FindBy(id="TGS_f_txtTo") WebElement txtTo;
	@FindBy(id="TGS_f_departDate") WebElement txtDepartDate;
	@FindBy(id="TGS_f_returnDate") WebElement txtReturnDate;
	@FindBy(id="TGS_f_cmbAdults") WebElement ddlAdults;
	@FindBy(id="TGS_f_cmbChildren") WebElement ddlChildren;
	@FindBy(id="tgs_f_cmbAge1") WebElement ddlChild1;
	@FindBy(id="tgs_f_cmbAge2") WebElement ddlChild2;
	@FindBy(id="TGS_f_cmbSeniors") WebElement ddlSeniors;
	@FindBy(id="TGS_f_cmbInfants") WebElement ddlInfants;
	@FindBy(id="TGS_f_cmbAirlines") WebElement ddlAirlines;
	@FindBy(id="TGS_f_cmbFlightClass") WebElement ddlFlightClass;
	@FindBy(id="TGS_f_butSearch") WebElement btnSearchForFlight;
	
	public static Function<WebDriver,WebElement> presenceOfElementLocated(final By locator) {
	    return new Function<WebDriver, WebElement>() {
	        //@Override
	        public WebElement apply(WebDriver driver) {
	            return driver.findElement(locator);
	        }
	    };
	}
	
	public HomePage flightsClicked(){
		waitForPageUntilElementIsVisible(By.id("TGS_sb_fImg"), 8000);
		System.out.println("Flight radio button value is = " + rbtFlights.getTagName());
		rbtFlights.click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return new HomePage(driver);
	}
	
	public HomePage populateFlightsForm(DataTable table1) throws InterruptedException{
		//System.out.println(table);
	    List<List<String>> data = table1.raw();
	    System.out.println(data.get(1).get(1));
	   
	    txtFrom.sendKeys(data.get(1).get(1));
	    txtTo.sendKeys(data.get(2).get(1));
	    txtDepartDate.clear();
	    txtDepartDate.sendKeys(data.get(3).get(1));
	    txtReturnDate.clear();
	    txtReturnDate.sendKeys(data.get(4).get(1));
	    new Select(ddlAdults).selectByVisibleText(data.get(5).get(1));
	    if(data.get(6).get(1).equals("2"))
	    {
	        new Select(ddlChildren).selectByVisibleText(data.get(6).get(1));
	        new Select(ddlChild1).selectByVisibleText(data.get(9).get(1));
	        new Select(ddlChild2).selectByVisibleText(data.get(10).get(1));
	    }
	    new Select(ddlSeniors).selectByVisibleText(data.get(7).get(1));
	    new Select(ddlInfants).selectByVisibleText(data.get(8).get(1));
	    new Select(ddlAirlines).selectByVisibleText(data.get(11).get(1));
	    new Select(ddlFlightClass).selectByVisibleText(data.get(12).get(1));
	    return new HomePage(driver);
	  }
	
	public FlightsPage btnSearchForFlightClicked(){
		btnSearchForFlight.click();
		return new FlightsPage(driver);
	}
	
	/************Cars search section**************/
	@FindBy(id="TGS_sb_rImg") WebElement rbtCars;
	@FindBy(id="TGS_r_txtPuLocation") WebElement txtPickupLocation;
	@FindBy(id="TGS_r_txtDoLocation") WebElement txtDropoffLocation;
	@FindBy(id="TGS_r_txtPuDate") WebElement txtPickupDate;
	@FindBy(id="TGS_r_txtDoDate") WebElement txtDropoffDate;
	@FindBy(id="TGS_r_butSearch") WebElement btnSearchNowCars;
	
	public HomePage carsClicked(){
		waitForPageUntilElementIsVisible(By.id("TGS_sb_rImg"), 8000);
		System.out.println("Cars radio button value is = " + rbtCars.getTagName());
		rbtCars.click();
		return new HomePage(driver);
	}
	
	public HomePage populateCarsForm(DataTable table2){
		List<List<String>> data = table2.raw();
	    //System.out.println(data.get(1).get(1));
	   
		txtPickupLocation.sendKeys(data.get(1).get(1));
		txtDropoffLocation.clear();
		txtDropoffLocation.sendKeys(data.get(2).get(1));
		txtPickupDate.clear();
		txtPickupDate.sendKeys(data.get(3).get(1));
		txtDropoffDate.clear();
		txtDropoffDate.sendKeys(data.get(4).get(1));
		
		return new HomePage(driver);
	}
	
	public CarsPage btnSearchForCarsClicked(){
		btnSearchNowCars.click();
		return new CarsPage(driver);
	}
	
	
	
}	

	

