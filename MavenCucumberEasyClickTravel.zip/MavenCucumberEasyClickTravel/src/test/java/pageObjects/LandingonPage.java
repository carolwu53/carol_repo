package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LandingonPage extends AbstractPage {
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl0_hlTab")
	WebElement home;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl1_hlTab")
	WebElement hotels;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl2_hlTab")
	WebElement flights;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl3_hlTab")
	WebElement cruises;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl4_hlTab")
	WebElement coupons;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl5_hlTab")
	WebElement vocation_home;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl6_hlTab")
	WebElement cars;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl7_hlTab")
	WebElement packages;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl8_hlTab")
	WebElement activities;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_repTabs__ctl9_hlTab")
	WebElement deals;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_layer1_rptSubmenu__ctl1_tdSubMenu")
	WebElement search_reservations;
	
	@FindBy(how = How.ID, using = "_ctl0_ucMNB_layer1_rptSubmenu__ctl2_tdSubMenu")
	WebElement my_account;
	
	public LandingonPage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
		
	}
	
	public HomePage navigateToHomePage(){
		home.click();
		return new HomePage(driver);
	}
	
    public void verifyisHomePage(){
    	home.click();
    	driver.getCurrentUrl().contains("hp.aspx");
	}

    public FlightsPage navigateToFlightsPage(){
		flights.click();
		return new FlightsPage(driver);
	}
	
    public void verifyisFlightsPage(){
    	flights.click();
    	driver.getCurrentUrl().contains("PageFlightSearch.aspx");
	}


}
