# Kubera ElasticSearch Sync

## Introduction

The Kubera system is responsible for building the [ElasticSearch](https://www.elastic.co/products/elasticsearch) index which drives the search functionality in VPay 360, and for keeping the index in sync with source data as it changes.

Kubera is designed to be highly performant and is able to scale horizontally as our transaction processing needs grow. It uses [RabbitMQ](https://www.rabbitmq.com/) message queues for incoming requests as well as outgoing index updates. Various workers withing the system publish messages to these queues and/or consume messages from them.

[Kubera](https://en.wikipedia.org/wiki/Kubera) is named after the Hindu God of Wealth.

## High-Level Design

Kubera system is an ASP.NET Core app and runs on the .NET Core framework. It can run either as a Windows service or as a console application. It uses the built-in ASP.NET Core request/response web service functionality to provide "command & control" API calls to start requests, get status, etc.

The heart of the system is the `ProcessHost` class, which registers itself with ASP.NET Core DI as an [`IHostedService`](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/host/hosted-services), meaning that it runs in the background outside of any incoming scoped API requests.

Although we currently run Kubera as a Windows service in production, it is intended to be easily converted into a Docker container.

## The Kubera Cluster

Kubera is designed to run separate instances on multiple machines in order to improve throughput, scale horizontally, and provide improved fault tolerance. Currently, the member nodes of a cluster are listed in the configuration file for each instance.

While running, the various nodes will communicate with each other and elect a "leader". The leader node will build various stats, health check results, and config info from individual nodes into a single "cluster report", then distribute this report back out to the other nodes. If the leader node is terminated, one of the remaining nodes will become the

## Message Queues

There are two message queues used by Kubera.

* **Incoming Queue:** The Incoming queue holds messages which contain either a Range or List of Transaction IDs which need to be processed.
* **Outgoing Queue:** The Outgoing queue holds messages containing finished ElasticSearch documents which need to be added to the index.

## Workers

Workers are long-running processes which respond to requests and generate output as needed. The various types of workers are listed below.

### Change Detection Worker

The Change Detection worker polls the SQL Server CDC data for changes, and writes messages to the Incoming queue containing lists of Transaction IDs which have been changed.

Unlike the Incoming and Outgoing workers, the Change Detection worker is designed to have only one instance running at a time in the entire cluster. If multiple Change Detection workers are running, duplicate entries will be written in the Incoming queue, and the KuberaLastLsn table could have inconsistent data.

### Incoming Queue Consumer Worker

The Incoming queue contains requests to process a batch of Transaction IDs. The `QueueConsumerWorker` watches this queue for incoming requests, breaks them into smaller pieces if necessary, and dispatches them to `BatchRunner` instances.

A `BatchRunner` instance only lives long enough to process its one batch of transactions asynchronously. It fires off requests to multiple "Data Handlers" (derived from `IDataHandler`). Each Data Handler fetches a specific type of data from a single source, also asynchronously.

When all Data Handlers have fetched their data for the given batch, they are called, in order, to assemble a `KuberaTransaction` (formerly called `RedscreenDoc`) from their results. This is mostly done using `AutoMapper`, with the mapping configuration defined in `KuberaMapperProfile`.

As each Batch Runner finishes its job, the Queue Consumer Worker takes the batch and submits it to the Outgoing Kubera Queue.

### Outgoing Queue Consumer Worker

TODO...

## API

Kubera has a built-in REST API for querying stats and issuing commands.

TODO document API, and/or build w/ Swagger...